var searchData=
[
  ['l_0',['l',['../struct_point.html#a6df339da62f59b3b445829abcd2ea34d',1,'Point']]]
];
