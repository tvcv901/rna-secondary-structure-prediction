var searchData=
[
  ['sweep_2dline_20algorithm_0',['Sweep-Line Algorithm',['../index.html',1,'']]]
];
